import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * This program reads a text file, counts occurrences of each word, and
 * generates an HTML document listing words and their counts in alphabetical
 * order using OSU CSE Components.
 *
 * @author David Park
 */
public final class WordCounter {

    /**
     * final string for all non word characters.
     */
    private static final String NON_WORD = "\\W+";

    /**
     * Private constructor to prevent instantiation.
     */
    private WordCounter() {
    }

    /**
     * Reads words from the given file and counts their occurrences.
     *
     * @param inputFilePath
     *            the path to the input file
     * @param wordsMap
     *            the map where word counts are stored
     */
    private static void countWords(String inputFilePath,
            Map<String, Integer> wordsMap) {
        SimpleReader inFile = new SimpleReader1L(inputFilePath);
        while (!inFile.atEOS()) {
            String line = inFile.nextLine();
            Sequence<String> words = parseWords(line);
            // iterate through each word in the sequence
            for (int i = 0; i < words.length(); i++) {
                //set word as the word we receive
                String word = words.entry(i);
                //if the word is in map, we retrieve its count
                if (wordsMap.hasKey(word)) {
                    int count = wordsMap.value(word);
                    //increment and update map
                    wordsMap.replaceValue(word, count + 1);
                } else {
                    wordsMap.add(word, 1);
                }
            }
        }
        inFile.close();
    }

    /**
     * Parses a line of text into words based on the class-level reg expression.
     *
     * @param line
     *            the line of text to parse
     * @return a sequence of words
     */
    private static Sequence<String> parseWords(String line) {
        Sequence<String> words = new Sequence1L<>();
        String[] parts = line.split(NON_WORD);
        // iterate over each part resulting from the split
        for (String part : parts) {
            // check if part is not empty
            if (!part.isEmpty()) {
                // add nonempty part to sequence
                words.add(words.length(), part);
            }
        }
        return words;
    }

    /**
     * Inserts a word into a sequence in alphabetical order.
     *
     * @param sortedWords
     *            the sequence to insert the word into
     * @param word
     *            the word to insert
     */
    private static void insertInOrder(Sequence<String> sortedWords,
            String word) {
        // initialize position to start at beginning
        int position = 0;
        // traverse and find insertion point. continues until it finds a word
        // alphabetically greater than the other.
        while (position < sortedWords.length()
                && sortedWords.entry(position).compareToIgnoreCase(word) < 0) {
            position++;
            // increment the position
        }
        // add the new word to the sequence we found
        sortedWords.add(position, word);
    }

    /**
     * Writes the words and their counts to an HTML file, sorted alphabetically.
     *
     * @param outputFilePath
     *            the path to the output HTML file
     * @param inputFilePath
     *            the path to the input file, used in the title
     * @param wordsMap
     *            the map containing words and their counts
     */
    private static void writeHtml(String outputFilePath, String inputFilePath,
            Map<String, Integer> wordsMap) {
        SimpleWriter outFile = new SimpleWriter1L(outputFilePath);
        // start of HTML Document
        outFile.println("<!DOCTYPE html>");
        outFile.println("<html>");
        outFile.println("<head><title>Word Count</title></head>");
        outFile.println("<body>");

        // add the heading
        outFile.println("<h1>Words Counted in " + inputFilePath + "</h1>");
        outFile.println("<table border=\"1\">");
        outFile.println("<tr><th>Word</th><th>Count</th></tr>");

        //initialize sequence to hold words sorted
        Sequence<String> sortedWords = new Sequence1L<>();
        //iterate through each entry in the map
        for (Map.Pair<String, Integer> entry : wordsMap) {
            //insert each word into the sequence in alphabetical order
            insertInOrder(sortedWords, entry.key());
        }

        // write each word and its count as a row
        for (int i = 0; i < sortedWords.length(); i++) {
            String word = sortedWords.entry(i);
            outFile.println("<tr><td>" + word + "</td><td>"
                    + wordsMap.value(word) + "</td></tr>");
        }
        // close table and html
        outFile.println("</table>");
        outFile.println("</body>");
        outFile.println("</html>");
        outFile.close();
    }

    /**
     * Main method to run the program.
     *
     * @param args
     *            command line arguments (not used)
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // Prompt the user to enter the path to the input file and read the input
        out.print("Enter the path to the input file: ");
        String inputFilePath = in.nextLine();
        // Prompt the user to enter the path where the output HTML file
        out.print("Enter the path to the output HTML file: ");
        String outputFilePath = in.nextLine();

        // Initialize a map to store words and their counts
        Map<String, Integer> wordsMap = new Map1L<>();
        // Process the input file to count occurrences of each word
        countWords(inputFilePath, wordsMap);
        // Generate and write the HTML output
        writeHtml(outputFilePath, inputFilePath, wordsMap);

        in.close();
        out.close();
    }
}
